﻿namespace Oceans.Exercise
{
    public enum PaymentType
    {
        Visa,
        MasterCard,
        Chase,
        AmericanExpress,
        Discover
    }
}